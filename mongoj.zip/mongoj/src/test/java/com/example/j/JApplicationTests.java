package com.example.j;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.j.model.Student;
import com.example.j.repository.StudentRepo;

@SpringBootTest
class JApplicationTests {

    @Autowired
    private StudentRepo studentRepo;

    @Test
    public void testCreate() {
        Student s = new Student();
        s.setSid(1);
        s.setSname("Kavya");
        studentRepo.save(s);
        s.setSid(2);
        s.setSname("hitesh");
        studentRepo.save(s);
        s.setSid(3);
        s.setSname("yashas");
        studentRepo.save(s);
       
    }

    @Test
    public void testReadAll() {
        Iterable<Student> list = studentRepo.findAll();
        System.out.println(list);
      
    }

    @Test
    public void testUpdate() {
        Student s = studentRepo.findById(1).get();
            s.setSname("shreyas");
            studentRepo.save(s);
          
    }

    @Test
    public void testDelete() {
        studentRepo.deleteById(2);

    }
}
